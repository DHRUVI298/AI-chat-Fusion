import streamlit as st
from random import choices  # For generating sample content suggestions

# Website information gathering
st.title("Website Design Assistant")
st.write("This app helps you gather information and brainstorm ideas for your website.")

website_name = st.text_input("Website Name:")

# Target audience selection (multiselect with default)
target_audience_options = ["Everyone", "Students", "Professionals", "Tech Enthusiasts"]
target_audience = st.multiselect("Who is your target audience?", target_audience_options, default=["Everyone"])

website_goal = st.selectbox("What is the main goal of your website?",
                             ["Inform", "Sell products/services", "Build a community"])

# Sample content suggestions based on selections with informative error handling
def generate_content_suggestions(target_audience, website_goal):
    content_suggestions = {
        "Everyone": {
            "Inform": ["Blog posts", "FAQs", "About Us page"],
            "Sell products/services": ["Product descriptions", "Customer testimonials", "Pricing page"],
            "Build a community": ["Forum", "Events page", "Member directory"],
        },
        "Students": {
            "Inform": ["Course information", "Faculty profiles", "Campus resources"],
            "Sell products/services": ["Student discounts", "Career services", "University merchandise"],
            "Build a community": ["Student clubs", "Social events calendar", "Online forum"],
        },
        "Tech Enthusiasts": {  # Add suggestions for Tech Enthusiasts
            "Inform": ["Tech tutorials", "Product reviews", "Industry news"],
            "Sell products/services": ["Software subscriptions", "Hardware components", "Online courses"],
            "Build a community": ["Tech forums", "Hackathons", "Meetup groups"],
        },
        "Professionals": {  # Add suggestions for Professionals
            "Inform": ["Industry reports", "White papers", "Case studies"],
            "Sell products/services": ["B2B solutions", "Pricing plans", "Client testimonials"],
            "Build a community": ["Professional networking", "Industry events", "Online forums"],
        }
    }

    # Handle empty or unsupported target audience gracefully
    if not target_audience:
        return ["Please select a target audience."]
    elif target_audience[0] not in content_suggestions:
        return [f"Content suggestions for '{target_audience[0]}' are not currently available. "
                f"Please select another target audience or consider adding suggestions for '{target_audience[0]}' "
                f"to the 'content_suggestions' dictionary."]  # Informative message

    selected_audience = target_audience.pop()
    return choices(content_suggestions[selected_audience][website_goal], k=3)  # Randomly pick 3 suggestions

content_ideas = generate_content_suggestions(target_audience, website_goal)

st.subheader("Website Content Inspiration:")
st.write("Here are some content ideas based on your target audience and website goal:")
for idea in content_ideas:
    st.write("- " + idea)



