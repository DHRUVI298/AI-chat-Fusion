import streamlit as st
import fitz  # PyMuPDF library

def edit_pdf_text(pdf_file, old_text, new_text):
    """Edits text in a PDF by replacing all occurrences of a specified text.

    Args:
        pdf_file (streamlit.uploadedfile.UploadedFile): The uploaded PDF file.
        old_text (str): The text to be replaced.
        new_text (str): The new text to replace all occurrences of the specified text.

    Returns:
        bytes: The edited PDF content in bytes format.
    """
    try:
        # Open the PDF document
        doc = fitz.open(stream=pdf_file.read())

        # Iterate through all pages and search for the specified text
        for page in doc:
            # Search for text based on coordinates
            blocks = page.search_for(old_text)
            if blocks:
                # Iterate through each block and draw a rectangle over the old text
                for block in blocks:
                    x0, y0, x1, y1 = block
                    page.add_redact_annot((x0, y0, x1, y1))
                    page.apply_redactions()
                    page.insert_text(block[:2], new_text)  # Replace text at specified location

        # Save the edited PDF
        edited_pdf_data = doc.write()
        return edited_pdf_data

    except Exception as e:
        st.error(f"Error editing PDF: {e}")
        return None

def main():
    """Builds the Streamlit app for PDF text editing."""
    st.title("PDF Text Editor")
    uploaded_file = st.file_uploader("Upload PDF", type="pdf")

    # User input for text editing
    old_text = st.text_input("Enter text to be replaced")
    new_text = st.text_input("Enter new text")

    # Download edited PDF
    if uploaded_file is not None and old_text and new_text:
        edited_pdf = edit_pdf_text(uploaded_file, old_text, new_text)
        if edited_pdf:
            st.download_button(label="Download Edited PDF", data=edited_pdf, file_name="edited.pdf")

if __name__ == "__main__":
    main()
